package br.com.restassuredapitesting.suites;

public interface SecurityTests {
}
